<?php
    define('DB_HOST', 'localhost');
	define('DB_NAME', 'smslogin');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('BASE_URL', 'http://localhost/SMSlogin/');

	//SMTP
	define("M_HOST", 'smtp.gmail.com');
	define("M_USERNAME", 'YourEmailGoesHere');
	define("M_PASSWORD", 'YourEmailPasswordGoesHere');
	define("M_SMTPSECURE", 'ssl');
	define("M_PORT", "465");
	
?>
